from flask import Flask, request, render_template, redirect, url_for, flash, jsonify, session
import json
import os
import hashlib

app = Flask(__name__)
app.secret_key = 'your-secret-key-here'  # Change this in production

# File to store user data
USERS_FILE = 'users.json'

def load_users():
    """Load users from JSON file"""
    if os.path.exists(USERS_FILE):
        with open(USERS_FILE, 'r') as f:
            return json.load(f)
    return {}

def save_users(users):
    """Save users to JSON file"""
    with open(USERS_FILE, 'w') as f:
        json.dump(users, f, indent=2)

def hash_password(password):
    """Simple password hashing"""
    return hashlib.sha256(password.encode()).hexdigest()

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/welcome')
def welcome():
    return render_template('welcome.html')

@app.route('/c')
def clicker():
    if 'username' not in session:
        flash('Please sign in to play the clicker game', 'error')
        return redirect(url_for('welcome'))

    users = load_users()
    username = session['username']

    # Initialize clicks if not present (for existing users)
    if 'clicks' not in users[username]:
        users[username]['clicks'] = 0
        save_users(users)

    current_clicks = users[username]['clicks']
    return render_template('clicker game.html', username=username, clicks=current_clicks)

@app.route('/signup', methods=['POST'])
def signup():
    username = request.form.get('username')
    password = request.form.get('password')
    gender = request.form.get('gender')

    if not username or not password or not gender:
        flash('All fields are required', 'error')
        return redirect(url_for('index'))

    users = load_users()

    # Check if user already exists
    if username in users:
        flash('Username already exists', 'error')
        return redirect(url_for('index'))

    # Save user data
    users[username] = {
        'password': hash_password(password),
        'gender': gender,
        'clicks': 0
    }
    save_users(users)

    flash('Account created successfully! You can now sign in.', 'success')
    return redirect(url_for('welcome'))

@app.route('/signin', methods=['POST'])
def signin():
    username = request.form.get('username')
    password = request.form.get('password')

    if not username or not password:
        flash('Username and password are required', 'error')
        return redirect(url_for('welcome'))

    users = load_users()

    # Check credentials
    if username in users and users[username]['password'] == hash_password(password):
        session['username'] = username
        flash(f'Welcome back, {username}!', 'success')
        return f'<h1>Welcome {username} to the website made by your ideas!</h1><a href="c">Back to Home</a><br><a href="c">clicker game</a>'
    else:
        flash('Invalid username or password', 'error')
        return redirect(url_for('welcome'))

@app.route('/logout')
def logout():
    session.pop('username', None)
    flash('You have been logged out', 'success')
    return redirect(url_for('index'))

@app.route('/save_click', methods=['POST'])
def save_click():
    if 'username' not in session:
        return jsonify({'error': 'Not logged in'}), 401

    users = load_users()
    username = session['username']

    # Initialize clicks if not present
    if 'clicks' not in users[username]:
        users[username]['clicks'] = 0

    # Increment click count
    users[username]['clicks'] += 1
    save_users(users)

    return jsonify({'clicks': users[username]['clicks']})

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)

    