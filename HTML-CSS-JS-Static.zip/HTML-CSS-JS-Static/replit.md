# Overview

This is a simple Flask-based web application that provides user registration functionality. The application allows users to sign up with a username, password, and gender selection, storing user data in a local JSON file. It features a minimal, clean UI with a sign-up form and a welcome page for successful registrations.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
- **Template Engine**: Uses Flask's built-in Jinja2 templating system
- **Styling**: Custom CSS with a modern, card-based design using a light slate background
- **UI Components**: Centered form layout with responsive design and focus states
- **Client-Side Logic**: Minimal JavaScript (currently empty script.js file)

## Backend Architecture
- **Framework**: Flask web framework with Python
- **Routing**: Simple route-based architecture with GET and POST endpoints
- **Session Management**: Flask's built-in session handling with flash messages for user feedback
- **Security**: Basic password hashing using SHA-256 (note: this is not production-ready)

## Data Storage
- **Database**: File-based storage using JSON format
- **User Data**: Stored in `users.json` file with username as key
- **Data Operations**: Simple load/save functions for JSON file manipulation
- **No ORM**: Direct file I/O operations without database abstraction layer

## Authentication System
- **Password Security**: SHA-256 hashing (basic implementation)
- **User Validation**: Username uniqueness checking
- **Session Security**: Flask secret key for session management
- **Form Validation**: Server-side validation for required fields

## Application Structure
- **Main Application**: Single `app.py` file containing all backend logic
- **Templates**: Separate HTML files in `templates/` directory
- **Static Assets**: CSS and JavaScript files in root directory
- **Configuration**: Hardcoded secret key (needs production update)

# External Dependencies

## Core Framework
- **Flask**: Python web framework for routing, templating, and request handling
- **Python Standard Library**: 
  - `json` for data serialization
  - `os` for file system operations
  - `hashlib` for password hashing

## Frontend Dependencies
- **No External Libraries**: Pure HTML/CSS implementation without frameworks
- **Browser APIs**: Standard form submission and DOM manipulation

## Development Environment
- **No Database Server**: Uses local file storage instead of traditional database
- **No External APIs**: Self-contained application without third-party service calls
- **Static File Serving**: Flask's built-in static file handling

Note: The application currently has an incomplete signup route in `app.py` that needs completion. The password hashing implementation using SHA-256 is not suitable for production use and should be replaced with a more secure solution like bcrypt or Argon2.