from flask import Flask, request, render_template, redirect, url_for, flash, session
from flask_socketio import SocketIO, emit, join_room, leave_room
import json
import os
import hashlib
from datetime import datetime

app = Flask(__name__)
app.secret_key = 'your-secret-key-here'  # Change this in production
socketio = SocketIO(app, cors_allowed_origins="*")

# File to store user data
USERS_FILE = 'users.json'
CHAT_HISTORY_FILE = 'chat_history.json'

# In-memory chat storage (will also persist to file)
chat_messages = []


def load_users():
    """Load users from JSON file"""
    if os.path.exists(USERS_FILE):
        with open(USERS_FILE, 'r') as f:
            return json.load(f)
    return {}

def save_users(users):
    """Save users to JSON file"""
    with open(USERS_FILE, 'w') as f:
        json.dump(users, f, indent=2)

def hash_password(password):
    """Simple password hashing"""
    return hashlib.sha256(password.encode()).hexdigest()

def load_chat_history():
    """Load chat history from JSON file"""
    global chat_messages
    if os.path.exists(CHAT_HISTORY_FILE):
        with open(CHAT_HISTORY_FILE, 'r') as f:
            chat_messages = json.load(f)
    else:
        chat_messages = []
    return chat_messages

def save_chat_history():
    """Save chat history to JSON file"""
    with open(CHAT_HISTORY_FILE, 'w') as f:
        json.dump(chat_messages, f, indent=2)

# Load chat history on startup
load_chat_history()


@app.route('/')
def index():
    return render_template('index.html')

@app.route('/welcome')
def welcome():
    return render_template('welcome.html')

@app.route('/platform')
def platform():
    username = session.get('username', 'Guest')
    return render_template('platform.html', username=username)

@app.route('/website')
def website():
    if 'username' not in session:
        flash('Please sign in to access the website', 'error')
        return redirect(url_for('welcome'))
    
    username = session['username']
    return render_template('website.html', username=username)


@app.route('/signup', methods=['POST'])
def signup():
    username = request.form.get('username')
    password = request.form.get('password')
    gender = request.form.get('gender')

    if not username or not password or not gender:
        flash('All fields are required', 'error')
        return redirect(url_for('index'))

    # Validate username (alphanumeric and underscores only, 3-20 chars)
    import re
    if not re.match(r'^[a-zA-Z0-9_]{3,20}$', username):
        flash('Username must be 3-20 characters and contain only letters, numbers, and underscores', 'error')
        return redirect(url_for('index'))

    users = load_users()

    # Check if user already exists
    if username in users:
        flash('Username already exists', 'error')
        return redirect(url_for('index'))

    # Save user data
    users[username] = {
        'password': hash_password(password),
        'gender': gender
    }
    save_users(users)

    flash('Account created successfully! You can now sign in.', 'success')
    return redirect(url_for('welcome'))

@app.route('/signin', methods=['POST'])
def signin():
    username = request.form.get('username')
    password = request.form.get('password')

    if not username or not password:
        flash('Username and password are required', 'error')
        return redirect(url_for('welcome'))

    users = load_users()

    # Check credentials
    if username in users and users[username]['password'] == hash_password(password):
        session['username'] = username
        return redirect(url_for('website'))
    else:
        flash('Invalid username or password', 'error')
        return redirect(url_for('welcome'))

@app.route('/logout')
def logout():
    session.pop('username', None)
    flash('You have been logged out', 'success')
    return redirect(url_for('index'))

# WebSocket event handlers for multiplayer
@socketio.on('connect')
def handle_connect():
    if 'username' in session:
        emit('user_connected', {'username': session['username']}, broadcast=True)

@socketio.on('disconnect')
def handle_disconnect():
    if 'username' in session:
        emit('user_disconnected', {'username': session['username']}, broadcast=True)

@socketio.on('join_room')
def handle_join_room(data):
    if 'username' in session:
        room = data.get('room', 'default')
        # Use unified room for both website and platformer
        unified_room = 'unified_chat' if room in ['default', 'platformer_game'] else room
        join_room(unified_room)
        
        # Send chat history to the newly joined user
        emit('chat_history', {'messages': chat_messages})
        
        emit('user_joined', {
            'username': session['username'],
            'room': unified_room
        }, room=unified_room)

@socketio.on('leave_room')
def handle_leave_room(data):
    if 'username' in session:
        room = data.get('room', 'default')
        leave_room(room)
        emit('user_left', {
            'username': session['username'],
            'room': room
        }, room=room)

@socketio.on('send_message')
def handle_message(data):
    if 'username' in session:
        room = data.get('room', 'default')
        # Use unified room for both website and platformer
        unified_room = 'unified_chat' if room in ['default', 'platformer_game'] else room
        
        message_data = {
            'username': session['username'],
            'message': data.get('message', ''),
            'timestamp': data.get('timestamp', datetime.now().strftime('%H:%M:%S'))
        }
        
        # Store message in history
        chat_messages.append(message_data)
        
        # Keep only last 100 messages to prevent file from growing too large
        if len(chat_messages) > 100:
            chat_messages.pop(0)
        
        # Save to file
        save_chat_history()
        
        emit('receive_message', message_data, room=unified_room)

@socketio.on('user_action')
def handle_user_action(data):
    if 'username' in session:
        room = data.get('room', 'default')
        # Use unified room for platformer actions
        unified_room = 'unified_chat' if room == 'platformer_game' else room
        emit('action_update', {
            'username': session['username'],
            'action': data.get('action', ''),
            'data': data.get('data', {})
        }, room=unified_room, include_self=False)

if __name__ == '__main__':
    socketio.run(app, host='0.0.0.0', port=5000, debug=True)