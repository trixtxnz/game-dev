# Overview

This is a Flask-based web application that provides user authentication. The application allows users to register and log in. User data is persisted in a JSON file, and the application uses session-based authentication.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Backend Architecture

**Framework**: Flask web framework with session-based authentication

**Data Storage**: File-based JSON storage (`users.json`) for user accounts and preferences
- **Problem**: Need persistent storage for user data without database complexity
- **Solution**: Simple JSON file with load/save utilities
- **Pros**: No database setup required, easy to inspect and debug
- **Cons**: Not suitable for concurrent writes, scalability limitations, no ACID guarantees

**Authentication**: SHA-256 password hashing with server-side sessions
- **Problem**: Secure user authentication and password storage
- **Solution**: Hash passwords with SHA-256 before storage, use Flask sessions for authentication state
- **Pros**: Simple implementation, passwords not stored in plaintext
- **Cons**: SHA-256 alone lacks salt, vulnerable to rainbow table attacks (should use bcrypt/argon2 in production)

**User Data Model**: Each user object contains:
- `password`: Hashed password string
- `gender`: User gender field

## Frontend Architecture

**Template Engine**: Jinja2 (Flask's default templating)

**Pages**:
- `index.html`: Landing/login page
- `welcome.html`: Post-login welcome page
- `website.html`: User homepage

**Styling Approach**: Inline CSS in templates
- Simple styling with no build process required

## Application Configuration

**Secret Key**: Hardcoded secret key for session management (flagged for production change)
- Note: Should be moved to environment variables for production deployment

**Session Management**: Server-side sessions using Flask's built-in session handling

# External Dependencies

## Python Packages
- **Flask** (>=3.1.2): Web framework for routing, templating, and request handling
- **Werkzeug** (>=3.1.3): WSGI utility library (Flask dependency)

## Storage
- **JSON File System**: `users.json` for persistent user data storage
  - Contains user credentials
  - No external database required

## Standard Library Dependencies
- **json**: For parsing and serializing user data
- **os**: For file system operations
- **hashlib**: For SHA-256 password hashing

Note: The application currently has no external API integrations, third-party services, or database systems. All data is self-contained within the application file system.